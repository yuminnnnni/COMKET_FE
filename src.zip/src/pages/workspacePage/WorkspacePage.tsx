import * as S from './Workspace.Style';

export const WorkspacePage = () => {
  return (
    <div>
      <S.title>WorkspacePage</S.title>
    </div>
  );
};
