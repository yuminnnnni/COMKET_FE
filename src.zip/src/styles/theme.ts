export const theme = {
  fonts: {
    body: 'Pretandard, sans-serif',
    heading: 'Pretandard, sans-serif',
  }
};