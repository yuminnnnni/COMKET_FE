import * as S from "./TicketBoardView.Style";

export const TicketBoardView = () => {
    return (
        <S.Wrapper>
            보드뷰 창
        </S.Wrapper>
    );
}   